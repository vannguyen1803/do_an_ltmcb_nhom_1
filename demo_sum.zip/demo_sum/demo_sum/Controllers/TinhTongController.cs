﻿using demo_sum.Data;
using demo_sum.Models;
using Microsoft.AspNetCore.Mvc;


namespace demo_sum.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TinhTongController : ControllerBase
    {
        private readonly AppDbContext _context;
        public TinhTongController(AppDbContext context)
        {
            _context = context;
        }
        [HttpPost]
        public IActionResult TinhTong([FromBody] TinhTong input)
        {
            if (input == null)
                return BadRequest("Dữ liệu không hợp lệ");
            input.Tong = input.SoA + input.SoB;
            input.ThoiGian = DateTime.Now;
            _context.TinhTong_DEMO.Add(input);
            _context.SaveChanges();
            return Ok(new
            {
                message = "Tính tổng thành công!",
                a = input.SoA,
                b = input.SoB,
                tong = input.Tong,
                thoigian = input.ThoiGian
            });
        }
        [HttpGet]
        public IActionResult GetAll()
        {
            var list = _context.TinhTong_DEMO.ToList();
            return Ok(list);
        }
    }
}
