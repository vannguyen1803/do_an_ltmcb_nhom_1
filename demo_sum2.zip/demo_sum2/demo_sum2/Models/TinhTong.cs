﻿namespace demo_sum2.Models
{
    public class TinhTong
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public double SoA { get; set; }
        public double SoB { get; set; }
        public double Tong { get; set; }
        public DateTime ThoiGian { get; set; } = DateTime.UtcNow;
    }
}
