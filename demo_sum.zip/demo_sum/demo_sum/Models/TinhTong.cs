﻿using System.ComponentModel.DataAnnotations.Schema;

namespace demo_sum.Models
{
    [Table("TinhTong_DEMO")]
    public class TinhTong
    {
        public int Id { get; set; }
        public double SoA { get; set; }
        public double SoB { get; set; }
        public double Tong { get; set; }
        public DateTime ThoiGian { get; set; }
    }
}
