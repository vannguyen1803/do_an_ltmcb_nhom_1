﻿using Microsoft.EntityFrameworkCore;
using demo_sum.Models;
namespace demo_sum.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
           : base(options)
        {
        }

        public DbSet<TinhTong> TinhTong_DEMO { get; set; }
    }
}
