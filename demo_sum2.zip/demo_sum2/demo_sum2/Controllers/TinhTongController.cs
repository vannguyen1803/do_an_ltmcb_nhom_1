﻿using demo_sum2.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Net.Http.Json;
namespace demo_sum2.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TinhTongController : ControllerBase
    {
        private readonly IHttpClientFactory _httpFactory;
        private readonly string _firebaseBase;

        public TinhTongController(IHttpClientFactory httpFactory, IConfiguration config)
        {
            _httpFactory = httpFactory;
            _firebaseBase = config.GetValue<string>("Firebase:BaseUrl").TrimEnd('/');
        }

        // POST api/tinhtong
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] TinhTong model)
        {
            if (model == null) return BadRequest("No input");

            // Tính tổng ở backend
            model.Tong = model.SoA + model.SoB;
            model.ThoiGian = DateTime.UtcNow;

            var client = _httpFactory.CreateClient("firebase");

            // Ghi bằng POST -> Firebase tự generate key
            var firebaseUrl = $"{_firebaseBase}/TinhTong.json";
            var resp = await client.PostAsJsonAsync(firebaseUrl, model);

            if (!resp.IsSuccessStatusCode)
            {
                var err = await resp.Content.ReadAsStringAsync();
                return StatusCode((int)resp.StatusCode, new { ok = false, error = err });
            }

            // Firebase trả về object: { "name": "-Mxyz..." }
            var body = await resp.Content.ReadFromJsonAsync<Dictionary<string, string>>();
            var generatedId = body != null && body.ContainsKey("name") ? body["name"] : model.Id;

            // Optionally update the record with Id field so client can read it later
            // (Set .Id in the record under that generated key)
            model.Id = generatedId;
            var setUrl = $"{_firebaseBase}/TinhTong/{generatedId}.json";
            await client.PutAsJsonAsync(setUrl, model);

            return Ok(new { ok = true, id = generatedId, data = model });
        }

        // GET api/tinhtong
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var client = _httpFactory.CreateClient("firebase");
            var firebaseUrl = $"{_firebaseBase}/TinhTong.json";
            var resp = await client.GetAsync(firebaseUrl);

            if (!resp.IsSuccessStatusCode)
                return StatusCode((int)resp.StatusCode, await resp.Content.ReadAsStringAsync());

            // Firebase trả về object map: { "key1": {..}, "key2": {..} }
            var map = await resp.Content.ReadFromJsonAsync<Dictionary<string, TinhTong>>();

            // Trả mảng các bản ghi
            var list = map?.Select(kvp => {
                var v = kvp.Value;
                if (string.IsNullOrEmpty(v.Id)) v.Id = kvp.Key;
                return v;
            }).ToList() ?? new List<TinhTong>();

            return Ok(list);
        }
    }
}
